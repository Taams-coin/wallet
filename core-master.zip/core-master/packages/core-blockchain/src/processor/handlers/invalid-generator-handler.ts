import { BlockHandler } from "./block-handler";

export class InvalidGeneratorHandler extends BlockHandler {}
