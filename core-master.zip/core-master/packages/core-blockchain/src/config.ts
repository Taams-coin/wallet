import { Shared } from "@arkecosystem/core-interfaces";
export const config = new Shared.Config();
