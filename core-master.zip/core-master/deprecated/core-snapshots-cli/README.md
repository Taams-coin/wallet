# ARK Core - Snapshots CLI

<p align="center">
    <img src="https://raw.githubusercontent.com/ARKEcosystem/core/master/banner.png" />
</p>

## Deprecated
Note that this plugin is deprecated and should no longer be used

## Documentation

You can find installation instructions and detailed instructions on how to use this package at the [dedicated documentation site](https://docs.ark.io/guidebook/core/plugins/core-snapshots-cli.html).

## Security

If you discover a security vulnerability within this package, please send an e-mail to security@ark.io. All security vulnerabilities will be promptly addressed.

## Credits

-   [Joshua Noack](https://github.com/supaiku0)
-   [Kristjan Košič](https://github.com/kristjank)
-   [All Contributors](../../../../contributors)

## License

[MIT](LICENSE) © [ARK Ecosystem](https://ark.io)
