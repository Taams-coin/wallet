export const delegate = {
    username: "arkxdev",
    publicKey: "0310ad026647eed112d1a46145eed58b8c19c67c505a67f1199361a511ce7860c0",
};
