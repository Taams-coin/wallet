export const database = {
    getForgedTransactionsIds: () => [],
};
