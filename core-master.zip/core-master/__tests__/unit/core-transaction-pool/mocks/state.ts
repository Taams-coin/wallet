export const state = {
    cacheTransactions: () => null,
    removeCachedTransactionIds: () => null,
};
