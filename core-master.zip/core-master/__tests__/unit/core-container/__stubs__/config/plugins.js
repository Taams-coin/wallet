module.exports = {
    "./plugin-a": {
        enabled: true,
    },
    "./plugin-b": {
        enabled: true,
        property: "value",
    },
    "./plugin-c": {
        enabled: true,
    },
};
