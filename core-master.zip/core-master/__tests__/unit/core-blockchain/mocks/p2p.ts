export const p2p = {
    getNetworkHeight: () => 1,
    updateNetworkStatus: () => null,
    // tslint:disable-next-line: no-empty
    checkNetworkHealth: () => {},
    downloadBlocks: () => [],
    refreshPeersAfterFork: () => null,
    broadcastBlock: () => null,
    hasPeers: () => false,
};
