export const logger = {
    info: console.log,
    warn: console.log,
    error: console.error,
    debug: console.log,
    verbose: console.log,
};
