export const transactionPool = {
    buildWallets: () => null,
    purgeBlock: () => null,
    acceptChainedBlock: () => null,
    purgeSendersWithInvalidTransactions: () => null,
};
