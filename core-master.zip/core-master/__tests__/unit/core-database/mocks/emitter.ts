export const emitter = {
    on: jest.fn(),
    emit: jest.fn(),
    once: jest.fn(),
};
