export * from "./testnet"; // export testnet by default, if we want a different one we import from its path
