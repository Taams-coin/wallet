import * as delegates from "../../config/testnet/delegates.json";

export const delegatesSecrets = delegates.secrets;
