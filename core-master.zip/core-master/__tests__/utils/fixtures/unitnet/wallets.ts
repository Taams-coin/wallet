export { wallets } from "../../config/unitnet/wallets.json";
export { wallets2ndSig } from "../../config/unitnet/wallets2ndSig.json";
