module.exports = {
    passphrase: "clay harbor enemy utility margin pretty hub comic piece aerobic umbrella acquire",
};
